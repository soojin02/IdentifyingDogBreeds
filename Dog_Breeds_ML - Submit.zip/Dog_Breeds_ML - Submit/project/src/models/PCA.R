opt_num_clus <- 4
gmm_data <- GMM(PCA_dt[, 1:3], opt_num_clus)

# Read example submission file
example_sub <- fread("./project/volume/data/raw/example_sub.csv")

# Merge 'id'
final <- cbind(id, predict_GMM(PCA_dt[, 1:3], gmm_data$centroids, gmm_data$covariance_matrices, gmm_data$weights)$cluster_proba)

colnames(final)[-1] <- colnames(example_sub)[2:length(example_sub)]

# convert to data.table
final <- as.data.table(final)

# Write the processed data to a CSV file
fwrite(final, './project/volume/data/processed/submit_PCA_0.csv')