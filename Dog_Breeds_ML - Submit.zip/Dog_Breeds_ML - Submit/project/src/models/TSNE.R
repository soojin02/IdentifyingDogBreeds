rm(list = ls())
library(data.table)
library(caret)
library(ClusterR)
library(Rtsne) 

set.seed(1000)
data <- fread("./project/volume/data/raw/data.csv")

# store and remove the wine types
id <- data$id
data$id <- NULL

# PCA data = numeric
# remove ids
pca <- prcomp(data)

# variance explained by these components
screeplot(pca)

# summary of PCA
summary(pca)

# 1 or 2 component
biplot(pca)

# extract components => PCA
pca_dt <- data.table(unclass(pca)$x)

# add back id
pca_dt$id <- id

# ggplot
ggplot(pca_dt[1:1000,],aes(x = PC1,y = PC2)) + geom_point()

tsne_dat_1 <- Rtsne(pca_dt,  #PCA_DT
                    pca = F,   #F
                    perplexity = 30,   #5-50
                    max_iter = 1000,
                    check_duplicates = F)

tsne_dat_2 <- Rtsne(pca_dt,  #PCA_DT
                    pca = F,   #F
                    perplexity = 15,   #5-50
                    max_iter = 1000,
                    check_duplicates = F)

#extract the coordinates
tsne_data_table_1 <- data.table(tsne_dat_1$Y)
tsne_data_table_2 <- data.table(tsne_dat_2$Y)

tsne_dt <- cbind(tsne_data_table_1, tsne_data_table_2)


# add id
tsne_dt$id <- id

ggplot(tsne_dt,aes(x = V1,y = V2)) + geom_point()

# fit gmm to the data for all k=1 to k= max_clusters (major change)
k_bic <- Optimal_Clusters_GMM(tsne_dt[,.(V1,V2)],max_clusters = 10,criterion = "BIC")

# change in model fit between successive k values
delta_k <- c(NA,k_bic[-1] - k_bic[-length(k_bic)])

# plot to see valuse
del_k_tab <- data.table(delta_k = delta_k,k = 1:length(delta_k))

# plot 
ggplot(del_k_tab,aes(x = k,y = -delta_k)) + geom_point() + geom_line() +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) +
  geom_text(aes(label = k),hjust = 0, vjust = -1)

opt_num_clus <- 4

# Run the model with our chosen k value
gmm_data <- GMM(tsne_dt[,.(V1,V2)],opt_num_clus)

clusterInfo <- predict_GMM(tsne_dt[,.(V1,V2)],
                           gmm_data$centroids,
                           gmm_data$covariance_matrices,
                           gmm_data$weights)

# clusterInfo
clusterInfo$log_likelihood
clusterInfo$cluster_proba
clusterInfo$cluster_labels
tmp <- data.table(clusterInfo$cluster_proba)

tmp$id <- id
#set name for column
setnames(tmp,c("V1","V2","V3","V4"),c("breed_1","breed_2","breed_4","breed_3"))
#order change
setcolorder(tmp, c("id", "breed_1", "breed_2", "breed_3", "breed_4"))
#write final csv file
fwrite(tmp,'./project/volume/data/processed/submit_tsne_2.csv')
